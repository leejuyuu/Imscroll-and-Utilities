% run demo
disp('Demo 1: Denoising of a jump-sparse signal');
demoPotts_LaplacianNoise;

disp('Press space bar to continue');
pause;
disp('Demo 2: Segmentation of an image');
demoPotts2DColorSegmentation;