function u = minL2iPotts2DADMM(f, gamma, A, varargin)

u = iPotts2DADMM(f, gamma, A, 2, varargin{:});

end